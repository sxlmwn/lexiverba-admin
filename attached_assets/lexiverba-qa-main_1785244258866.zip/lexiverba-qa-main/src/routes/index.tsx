import { createFileRoute } from '@tanstack/react-router';
import { useEffect, useState, ReactNode } from 'react';
import { Sidebar } from '../qa/Sidebar';
import { Header } from '../qa/Header';
import { InteractiveModal } from '../qa/InteractiveModal';
import { DashboardPage } from '../qa/pages/DashboardPage';
import { ReviewQueuePage } from '../qa/pages/ReviewQueuePage';
import { PerformancePage } from '../qa/pages/PerformancePage';
import { ApprovedPage } from '../qa/pages/ApprovedPage';
import { RejectedPage } from '../qa/pages/RejectedPage';
import { GuidelinesPage } from '../qa/pages/GuidelinesPage';

export const Route = createFileRoute('/')({
  component: QAPortal,
});

const HEADERS: Record<string, { title: string; subtitle: string }> = {
  dashboard: { title: 'Quality Assurance', subtitle: 'Welcome back, Sofia' },
  queue: { title: 'Review Queue', subtitle: 'Documents awaiting your decision' },
  performance: { title: 'Performance', subtitle: 'Your review metrics and tier' },
  approved: { title: 'Approved', subtitle: 'Certified translations ready for delivery' },
  rejected: { title: 'Rejected', subtitle: 'Documents returned with revision notes' },
  guidelines: { title: 'Guidelines', subtitle: 'Review protocols and reference materials' },
  settings: { title: 'Settings', subtitle: 'Account and workspace preferences' },
  help: { title: 'Help', subtitle: 'Support and documentation' },
  logout: { title: 'Signing Out', subtitle: 'See you soon' },
};

function QAPortal() {
  const [currentTab, setCurrentTab] = useState('dashboard');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [modalData, setModalData] = useState<{ title: string; content: ReactNode } | null>(null);

  useEffect(() => {
    if (isDarkMode) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  }, [isDarkMode]);

  const handleItemClick = (title: string, content: ReactNode) => {
    if (!content) {
      setModalData(null);
    } else {
      setModalData({ title, content });
    }
  };

  const renderContent = () => {
    switch (currentTab) {
      case 'dashboard':
        return <DashboardPage isDarkMode={isDarkMode} onItemClick={handleItemClick} />;
      case 'queue':
        return <ReviewQueuePage isDarkMode={isDarkMode} onItemClick={handleItemClick} />;
      case 'performance':
        return <PerformancePage isDarkMode={isDarkMode} />;
      case 'approved':
        return <ApprovedPage isDarkMode={isDarkMode} onItemClick={handleItemClick} />;
      case 'rejected':
        return <RejectedPage isDarkMode={isDarkMode} onItemClick={handleItemClick} />;
      case 'guidelines':
        return <GuidelinesPage isDarkMode={isDarkMode} onItemClick={handleItemClick} />;
      default:
        return (
          <div className="animate-page-enter">
            <h1 className={`text-4xl font-semibold tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
              {HEADERS[currentTab]?.title ?? 'Coming Soon'}
            </h1>
            <p className={`text-sm font-medium mt-2 ${isDarkMode ? 'text-zinc-400' : 'text-slate-500'}`}>
              This section is not part of the QA portal yet.
            </p>
          </div>
        );
    }
  };

  const meta = HEADERS[currentTab] ?? HEADERS.dashboard;

  return (
    <div
      className={`min-h-screen transition-colors duration-300 ${
        isDarkMode ? 'bg-[#09090b] text-slate-100 dark' : 'bg-slate-50 text-slate-900'
      }`}
    >
      <Sidebar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        isDarkMode={isDarkMode}
        isCollapsed={isCollapsed}
        toggleCollapse={() => setIsCollapsed((v) => !v)}
      />
      <Header
        isDarkMode={isDarkMode}
        toggleDarkMode={() => setIsDarkMode((v) => !v)}
        isCollapsed={isCollapsed}
        title={meta.title}
        subtitle={meta.subtitle}
      />
      <main
        className={`transition-all duration-300 pt-28 pb-16 px-10 ${isCollapsed ? 'ml-20' : 'ml-72'}`}
      >
        {renderContent()}
      </main>

      <InteractiveModal
        isOpen={!!modalData}
        onClose={() => setModalData(null)}
        title={modalData?.title ?? ''}
        isDarkMode={isDarkMode}
      >
        {modalData?.content}
      </InteractiveModal>
    </div>
  );
}
