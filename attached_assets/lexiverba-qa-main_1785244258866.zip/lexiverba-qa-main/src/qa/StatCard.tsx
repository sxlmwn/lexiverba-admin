import React, { useState, useEffect } from 'react';

export interface StatCardData {
  id: string | number;
  title: string;
  value: string | number;
  badge: string;
  icon: string;
}

interface Props {
  cards: StatCardData[];
  isDarkMode: boolean;
}

const AnimatedStatValue: React.FC<{ value: string | number }> = ({ value }) => {
  const [displayValue, setDisplayValue] = useState<string | number>(0);

  useEffect(() => {
    const rawStr = String(value);
    const numericMatch = rawStr.match(/[\d,.]+/);
    if (!numericMatch) {
      setDisplayValue(value);
      return;
    }

    const numStr = numericMatch[0].replace(/,/g, '');
    const targetNum = parseFloat(numStr);
    if (isNaN(targetNum)) {
      setDisplayValue(value);
      return;
    }

    const prefix = rawStr.slice(0, numericMatch.index);
    const suffix = rawStr.slice((numericMatch.index ?? 0) + numericMatch[0].length);
    const isFloat = numStr.includes('.');

    const duration = 800;
    const steps = 40;
    const intervalTime = duration / steps;
    const increment = targetNum / steps;

    let current = 0;
    const timer = setInterval(() => {
      current += increment;
      if (current >= targetNum) {
        setDisplayValue(value);
        clearInterval(timer);
      } else {
        const formatted = isFloat ? current.toFixed(1) : Math.floor(current).toString();
        setDisplayValue(`${prefix}${formatted}${suffix}`);
      }
    }, intervalTime);

    return () => clearInterval(timer);
  }, [value]);

  return <>{displayValue}</>;
};

export const StatCardGrid: React.FC<Props> = ({ cards, isDarkMode }) => {
  const [hoveredCard, setHoveredCard] = useState<string | number | null>(null);

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 relative z-10">
      {cards.map((card) => {
        const isExpanded = hoveredCard === card.id;
        return (
          <div
            key={card.id}
            onMouseEnter={() => setHoveredCard(card.id)}
            onMouseLeave={() => setHoveredCard(null)}
            className={`p-6 rounded-[2.5rem] cursor-pointer smooth-card float-shadow float-hover transition-all duration-300 relative overflow-hidden flex flex-col justify-between min-h-[200px] ${
              isExpanded
                ? 'bg-gradient-to-br from-blue-600 via-blue-700 to-blue-900 text-white shadow-2xl border-2 border-blue-500'
                : isDarkMode
                ? 'bg-[#18181b] border-2 border-[#27272a] text-white shadow-sm hover:shadow-lg'
                : 'bg-white border-2 border-slate-200/80 text-slate-900 shadow-sm hover:shadow-lg'
            }`}
          >
            {isExpanded && (
              <div className="absolute -right-6 -top-6 opacity-10 text-white pointer-events-none transition-all duration-500">
                <span className="material-symbols-outlined text-[160px]">{card.icon}</span>
              </div>
            )}

            <div className="flex justify-between items-start relative z-10">
              <span
                className={`text-xs font-semibold uppercase tracking-widest ${
                  isExpanded ? 'text-blue-100' : isDarkMode ? 'text-zinc-300' : 'text-slate-700'
                }`}
              >
                {card.title}
              </span>
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center transition-all ${
                  isExpanded
                    ? 'bg-white/20 text-white'
                    : isDarkMode
                    ? 'bg-zinc-800 text-zinc-300'
                    : 'border border-slate-200 text-slate-600'
                }`}
              >
                <span className="material-symbols-outlined text-[18px]">{card.icon}</span>
              </div>
            </div>

            <div className="mt-8 relative z-10">
              <div className="text-5xl font-semibold tracking-tight mb-3">
                <AnimatedStatValue value={card.value} />
              </div>
              <div
                className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-semibold transition-colors ${
                  isExpanded
                    ? 'bg-white/20 text-white'
                    : isDarkMode
                    ? 'bg-zinc-800 text-zinc-300 border border-zinc-700'
                    : 'bg-slate-100 text-slate-600 border border-slate-200/60'
                }`}
              >
                {card.badge}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
