import React, { useState, ReactNode } from 'react';

interface Props {
  isDarkMode: boolean;
  onItemClick?: (title: string, content: ReactNode) => void;
}

const rows = [
  { doc: 'Diploma FR/EN Certified.pdf', icon: 'school', agency: 'Vanguard Legal', student: 'C. Dubois', reason: 'Missing sworn stamp on page 2', date: 'Oct 22, 2026' },
  { doc: 'Marriage Certificate IT/EN.pdf', icon: 'assignment', agency: 'Acme Global Corp', student: 'F. Rossi', reason: 'Terminology inconsistent with glossary', date: 'Oct 20, 2026' },
  { doc: 'Court Order RU/EN Draft.docx', icon: 'gavel', agency: 'Meridian Audit', student: 'D. Petrov', reason: 'Segment 14 omitted from translation', date: 'Oct 18, 2026' },
  { doc: 'Prescription Report AR/EN.pdf', icon: 'medical_services', agency: 'Helios Pharma', student: 'N. Haddad', reason: 'Dosage units mismatch source', date: 'Oct 15, 2026' },
];

export const RejectedPage: React.FC<Props> = ({ isDarkMode, onItemClick }) => {
  const [viewType, setViewType] = useState<'grid' | 'table'>('grid');

  const openRejectedModal = (r: (typeof rows)[0]) => {
    if (!onItemClick) return;
    onItemClick(
      `Rejection Notes - ${r.doc}`,
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-semibold px-3 py-1 rounded-full border uppercase tracking-widest bg-rose-500/10 text-rose-500 border-rose-500/30 badge-glow-rose">
            Returned for Revision
          </span>
          <span className={`text-xs font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
            Date: {r.date}
          </span>
        </div>

        <div className={`p-4 rounded-2xl border ${isDarkMode ? 'bg-rose-950/20 border-rose-900/40 text-rose-200' : 'bg-rose-50 border-rose-200 text-rose-900'}`}>
          <div className="text-xs font-semibold mb-1 uppercase tracking-wider text-rose-500">Rejection Reason</div>
          <p className="text-sm font-semibold">{r.reason}</p>
        </div>

        <div className={`p-4 rounded-2xl border ${isDarkMode ? 'bg-[#18181b] border-[#27272a]' : 'bg-slate-50 border-slate-200'}`}>
          <div className="text-xs font-semibold mb-1">Agency & Student Information</div>
          <div className={`text-sm ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>{r.agency}</div>
          <div className={`text-xs mt-0.5 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Student: {r.student}</div>
        </div>

        <div className="flex justify-end gap-3 pt-2">
          <button
            onClick={() => onItemClick('', null)}
            className="px-5 py-2 rounded-full bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold cursor-pointer shadow-md shadow-blue-600/30"
          >
            Close Rejection Notes
          </button>
        </div>
      </div>,
    );
  };

  return (
    <div className="space-y-8 animate-page-enter">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <h1 className={`text-4xl lg:text-5xl font-semibold tracking-tight leading-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
            Rejected Documents
          </h1>
          <p className={`text-sm font-medium mt-1 ${isDarkMode ? 'text-zinc-400' : 'text-slate-500'}`}>
            Documents returned for revision with reviewer notes.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Grid / Table View Switcher */}
          <div className={`flex p-1 rounded-full border ${isDarkMode ? 'bg-[#18181b] border-[#27272a]' : 'bg-white border-slate-200/80'}`}>
            <button
              onClick={() => setViewType('grid')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-full transition-all flex items-center gap-1.5 cursor-pointer ${
                viewType === 'grid' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span className="material-symbols-outlined text-[16px]">grid_view</span>
              <span>Grid</span>
            </button>
            <button
              onClick={() => setViewType('table')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-full transition-all flex items-center gap-1.5 cursor-pointer ${
                viewType === 'table' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span className="material-symbols-outlined text-[16px]">table_rows</span>
              <span>Table</span>
            </button>
          </div>

          <button
            className={`flex items-center gap-2 px-5 py-3 rounded-full border font-semibold text-xs transition-all hover:scale-105 active:scale-95 cursor-pointer ${
              isDarkMode ? 'bg-[#18181b] border-[#27272a] text-white' : 'bg-white border-slate-200/80 text-slate-800'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">refresh</span>
            Refresh
          </button>
        </div>
      </div>

      {viewType === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {rows.map((r) => (
            <div
              key={r.doc}
              onClick={() => openRejectedModal(r)}
              className={`p-6 rounded-[2.5rem] border-2 float-shadow float-hover smooth-card animate-card-pop flex flex-col justify-between transition-all cursor-pointer ${
                isDarkMode ? 'bg-[#18181b] border-[#27272a] text-white' : 'bg-white border-slate-200/80 text-slate-900'
              }`}
            >
              <div>
                <div className="flex items-start gap-4 mb-4">
                  <div
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 text-blue-500 ${
                      isDarkMode ? 'bg-blue-500/10' : 'bg-blue-50'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[24px]">{r.icon}</span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="font-semibold text-sm truncate mb-1">{r.doc}</div>
                    <div className={`text-xs font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                      {r.agency} · Student: {r.student}
                    </div>
                    <div className={`text-xs font-semibold mt-2 line-clamp-2 ${isDarkMode ? 'text-rose-300' : 'text-rose-600'}`}>
                      Reason: {r.reason}
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-slate-200/50 dark:border-zinc-800 mt-4">
                <span className="text-[10px] font-semibold px-3 py-1 rounded-full border uppercase tracking-widest bg-rose-500/10 text-rose-500 border-rose-500/30 badge-glow-rose">
                  Rejected
                </span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    openRejectedModal(r);
                  }}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-semibold shadow-md shadow-blue-600/30 badge-shadow transition-all hover:scale-105 active:scale-95 cursor-pointer"
                >
                  View Notes
                  <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div
          className={`rounded-[2.5rem] border-2 float-shadow smooth-card overflow-hidden ${
            isDarkMode ? 'bg-[#18181b] border-[#27272a]' : 'bg-white border-slate-200/80'
          }`}
        >
          <table className="w-full text-left">
            <thead>
              <tr className={`text-[10px] font-semibold uppercase tracking-widest ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                <th className="px-6 py-4">Document</th>
                <th className="px-6 py-4">Agency</th>
                <th className="px-6 py-4">Student</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Reason</th>
                <th className="px-6 py-4">Rejected Date</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr
                  key={r.doc}
                  onClick={() => openRejectedModal(r)}
                  className={`border-t ${isDarkMode ? 'border-[#27272a] hover:bg-[#121215]' : 'border-slate-200/80 hover:bg-slate-50'} transition-colors cursor-pointer`}
                >
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-2xl flex items-center justify-center text-blue-500 ${isDarkMode ? 'bg-blue-500/10' : 'bg-blue-50'}`}>
                        <span className="material-symbols-outlined text-[20px]">{r.icon}</span>
                      </div>
                      <span className={`text-xs font-semibold ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>{r.doc}</span>
                    </div>
                  </td>
                  <td className={`px-6 py-4 text-xs font-semibold ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>{r.agency}</td>
                  <td className={`px-6 py-4 text-xs font-semibold ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>{r.student}</td>
                  <td className="px-6 py-4">
                    <span className="text-[10px] font-semibold px-3 py-1 rounded-full border uppercase tracking-widest bg-rose-500/10 text-rose-500 border-rose-500/30 badge-glow-rose">
                      Rejected
                    </span>
                  </td>
                  <td className={`px-6 py-4 text-xs font-semibold max-w-[260px] ${isDarkMode ? 'text-rose-300' : 'text-rose-600'}`}>{r.reason}</td>
                  <td className={`px-6 py-4 text-xs font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>{r.date}</td>
                  <td className="px-6 py-4 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        openRejectedModal(r);
                      }}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-semibold shadow-md shadow-blue-600/30 badge-shadow transition-all hover:scale-105 active:scale-95 cursor-pointer"
                    >
                      View Notes
                      <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
