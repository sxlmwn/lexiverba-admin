import React, { useState, useEffect, ReactNode } from 'react';
import { StatCardGrid } from '../StatCard';

interface Props {
  isDarkMode: boolean;
  onItemClick?: (title: string, content: ReactNode) => void;
}

const aiTools = [
  { icon: 'auto_awesome', title: 'AI Consistency Check', desc: 'Cross-check terminology across the entire document set.' },
  { icon: 'spellcheck', title: 'Grammar & Style', desc: 'Neural pass over grammar, register, and legal style.' },
  { icon: 'translate', title: 'Back-Translation', desc: 'Reverse translate segments to verify semantic parity.' },
  { icon: 'gavel', title: 'Compliance Audit', desc: 'ISO-17100 and jurisdiction rule validation.' },
];

const pipeline = [
  { icon: 'translate', label: 'Translating', count: 14 },
  { icon: 'verified', label: 'Quality Assurance', count: 8, active: true },
  { icon: 'approval', label: 'Legalizing', count: 5 },
  { icon: 'local_shipping', label: 'Transit', count: 3 },
  { icon: 'inventory_2', label: 'Delivered', count: 42 },
];

const documentsToReview = [
  { name: 'Legal Contract DE/EN Final.pdf', agency: 'Acme Global Corp', student: 'M. Klein', priority: 'High', icon: 'gavel' },
  { name: 'Medical Report ES/EN v2.docx', agency: 'Helios Pharma', student: 'A. Ruiz', priority: 'Medium', icon: 'medical_services' },
  { name: 'Patent Application ZH/EN.pdf', agency: 'Quantum Dynamics', student: 'L. Wei', priority: 'High', icon: 'description' },
  { name: 'Birth Certificate FR/EN.pdf', agency: 'Vanguard Legal', student: 'C. Dubois', priority: 'Low', icon: 'badge' },
];

const priorityStyles: Record<string, string> = {
  High: 'bg-rose-500/10 text-rose-500 border-rose-500/30 badge-glow-rose',
  Medium: 'bg-amber-500/10 text-amber-500 border-amber-500/30 badge-glow-amber',
  Low: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/30 badge-glow-emerald',
};

export const DashboardPage: React.FC<Props> = ({ isDarkMode, onItemClick }) => {
  const [chartType, setChartType] = useState<'bars' | 'line'>('bars');

  // Gauge animation state
  const [gaugePercent, setGaugePercent] = useState<number>(0);
  const [isGaugeAnimating, setIsGaugeAnimating] = useState<boolean>(false);

  const triggerGaugeAnimation = () => {
    if (isGaugeAnimating) return;
    setIsGaugeAnimating(true);
    setGaugePercent(0);

    const target = 91.2;
    const duration = 1000;
    const steps = 50;
    const stepTime = duration / steps;
    const increment = target / steps;

    let current = 0;
    const timer = setInterval(() => {
      current += increment;
      if (current >= target) {
        setGaugePercent(target);
        clearInterval(timer);
        setIsGaugeAnimating(false);
      } else {
        setGaugePercent(current);
      }
    }, stepTime);
  };

  useEffect(() => {
    triggerGaugeAnimation();
  }, []);

  const stats = [
    { id: 0, title: 'PENDING REVIEW', value: '8', badge: '3 ▲ Increased', icon: 'hourglass_top' },
    { id: 1, title: 'COMPLETED', value: '42', badge: '12 ▲ This Week', icon: 'task_alt' },
    { id: 2, title: 'REJECTED', value: '4', badge: '1 ▼ Decreased', icon: 'cancel' },
    { id: 3, title: 'TOTAL PROCESSED', value: '186', badge: 'On Target', icon: 'inventory_2' },
  ];

  const inProgressDashOffset = 251.32 * (1 - gaugePercent / 100);
  const completedDashOffset = 251.32 * (1 - (gaugePercent / 100) * 0.912);

  const openDocModal = (d: (typeof documentsToReview)[0]) => {
    if (!onItemClick) return;
    onItemClick(
      d.name,
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <span className={`text-[10px] font-semibold px-3 py-1 rounded-full border uppercase tracking-widest ${priorityStyles[d.priority]}`}>
            {d.priority} Priority
          </span>
          <span className={`text-xs font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
            {d.agency}
          </span>
        </div>

        <div className={`p-4 rounded-2xl border ${isDarkMode ? 'bg-[#18181b] border-[#27272a]' : 'bg-slate-50 border-slate-200'}`}>
          <div className="text-xs font-semibold mb-1">Student / Requester</div>
          <div className={`text-sm ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>{d.student}</div>
        </div>

        <div className={`p-4 rounded-2xl border ${isDarkMode ? 'bg-[#18181b] border-[#27272a]' : 'bg-slate-50 border-slate-200'}`}>
          <div className="text-xs font-semibold mb-1">Document Status</div>
          <div className="text-sm text-amber-500 font-semibold">Pending QA Certification Review</div>
        </div>

        <div className="flex justify-end gap-3 pt-4">
          <button
            onClick={() => onItemClick('', null)}
            className="px-5 py-2 rounded-full bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold cursor-pointer shadow-md shadow-blue-600/30"
          >
            Start Review Pass
          </button>
        </div>
      </div>,
    );
  };

  return (
    <div className="space-y-8 animate-page-enter">
      {/* SVG Definitions for Hatched Pattern */}
      <svg className="absolute w-0 h-0 pointer-events-none">
        <defs>
          <pattern id="hatchedPattern" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
            <line x1="0" y1="0" x2="0" y2="8" stroke={isDarkMode ? '#3f3f46' : '#cbd5e1'} strokeWidth="3" />
          </pattern>
        </defs>
      </svg>

      <div>
        <h1 className={`text-4xl lg:text-5xl font-semibold tracking-tight leading-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
          Quality Assurance
        </h1>
        <p className={`text-sm font-medium mt-1 ${isDarkMode ? 'text-zinc-400' : 'text-slate-500'}`}>
          Review, approve, and audit certified translations before delivery.
        </p>
      </div>

      {/* AI Tools */}
      <div>
        <div className={`text-[10px] font-semibold uppercase tracking-[0.2em] mb-4 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
          AI-Powered Tools
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {aiTools.map((t) => (
            <button
              key={t.title}
              className={`p-6 rounded-[2.5rem] border-2 smooth-card float-shadow float-hover text-left transition-all cursor-pointer ${
                isDarkMode ? 'bg-[#18181b] border-[#27272a] text-white' : 'bg-white border-slate-200/80 text-slate-900'
              }`}
            >
              <div className="w-11 h-11 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-lg shadow-blue-600/30 mb-4">
                <span className="material-symbols-outlined text-[22px]">{t.icon}</span>
              </div>
              <div className="font-semibold text-sm mb-1">{t.title}</div>
              <div className={`text-xs font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>{t.desc}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Stats */}
      <StatCardGrid cards={stats} isDarkMode={isDarkMode} />

      {/* Pipeline */}
      <div
        className={`p-8 rounded-[2.5rem] border-2 float-shadow smooth-card ${
          isDarkMode ? 'bg-[#18181b] border-[#27272a] text-white' : 'bg-white border-slate-200/80 text-slate-900'
        }`}
      >
        <div className="flex items-center justify-between mb-8">
          <div>
            <h3 className="text-xl font-semibold">Review Pipeline</h3>
            <p className={`text-xs font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
              Live stage counts across the certification flow
            </p>
          </div>
          <span className="text-[10px] font-semibold text-blue-500 bg-blue-500/10 px-3 py-1 rounded-full uppercase tracking-widest">
            Live
          </span>
        </div>
        <div className="flex items-center justify-between gap-2 overflow-x-auto">
          {pipeline.map((s, i) => (
            <React.Fragment key={s.label}>
              <div className="flex flex-col items-center gap-2 min-w-[120px]">
                <div
                  className={`w-14 h-14 rounded-full flex items-center justify-center border-2 transition-all ${
                    s.active
                      ? 'bg-blue-600 text-white border-blue-500 shadow-lg shadow-blue-600/30'
                      : isDarkMode
                      ? 'bg-[#121215] border-[#27272a] text-slate-400'
                      : 'bg-slate-50 border-slate-200 text-slate-500'
                  }`}
                >
                  <span className="material-symbols-outlined text-[24px]">{s.icon}</span>
                </div>
                <div className={`text-xs font-semibold ${s.active ? 'text-blue-500' : isDarkMode ? 'text-white' : 'text-slate-900'}`}>
                  {s.label}
                </div>
                <div className={`text-[11px] font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                  {s.count} docs
                </div>
              </div>
              {i < pipeline.length - 1 && (
                <div className={`flex-1 h-0.5 ${isDarkMode ? 'bg-[#27272a]' : 'bg-slate-200'}`}></div>
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Monthly Review Trends Card - 7 Cols */}
        <div
          className={`lg:col-span-7 p-8 rounded-[2.5rem] border-2 float-shadow smooth-card flex flex-col justify-between transition-colors ${
            isDarkMode ? 'bg-[#18181b] border-[#27272a] text-white' : 'bg-white border-slate-200/80 text-slate-900'
          }`}
        >
          <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
            <div>
              <h3 className="text-xl font-semibold">Monthly Review Trends</h3>
              <p className={`text-xs font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                Approved vs rejected throughput over the last 7 weeks
              </p>
            </div>

            <div className={`flex p-1 rounded-full border ${isDarkMode ? 'bg-[#27272a] border-zinc-700' : 'bg-slate-100 border-slate-200'}`}>
              <button
                onClick={() => setChartType('bars')}
                className={`px-3 py-1 text-xs font-semibold rounded-full transition-all flex items-center gap-1 cursor-pointer ${
                  chartType === 'bars' ? 'bg-blue-600 text-white shadow-md' : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <span className="material-symbols-outlined text-[16px]">bar_chart</span>
                <span>Bars</span>
              </button>
              <button
                onClick={() => setChartType('line')}
                className={`px-3 py-1 text-xs font-semibold rounded-full transition-all flex items-center gap-1 cursor-pointer ${
                  chartType === 'line' ? 'bg-blue-600 text-white shadow-md' : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <span className="material-symbols-outlined text-[16px]">show_chart</span>
                <span>Line</span>
              </button>
            </div>
          </div>

          {chartType === 'bars' ? (
            <div className="h-60 pt-8 flex items-end justify-between px-2 gap-3 relative">
              {[
                { day: 'W1', height: '60%', type: 'hatched' },
                { day: 'W2', height: '85%', type: 'solid' },
                { day: 'W3', height: '74%', type: 'active', badge: '74%' },
                { day: 'W4', height: '95%', type: 'dark' },
                { day: 'W5', height: '65%', type: 'hatched' },
                { day: 'W6', height: '50%', type: 'hatched' },
                { day: 'W7', height: '70%', type: 'hatched' },
              ].map((bar, i) => (
                <div key={i} className="flex-1 flex flex-col items-center h-full justify-end relative group">
                  {bar.badge && (
                    <div className="absolute -top-7 bg-blue-600 text-white text-[10px] font-semibold px-2.5 py-0.5 rounded-full shadow-md">
                      {bar.badge}
                    </div>
                  )}
                  <div
                    className={`w-full rounded-full transition-all duration-300 hover:scale-105 ${
                      bar.type === 'dark'
                        ? isDarkMode
                          ? 'bg-zinc-100 text-slate-900'
                          : 'bg-blue-900'
                        : bar.type === 'solid'
                        ? 'bg-blue-600'
                        : bar.type === 'active'
                        ? 'bg-blue-500'
                        : isDarkMode
                        ? 'bg-zinc-800 border-2 border-dashed border-zinc-700'
                        : 'bg-blue-50 border-2 border-dashed border-blue-200'
                    }`}
                    style={{ height: bar.height }}
                  ></div>
                  <span className="text-xs font-semibold text-zinc-400 mt-3">{bar.day}</span>
                </div>
              ))}
            </div>
          ) : (
            <div>
              <div className="h-60 relative w-full flex items-end">
                <svg className="w-full h-full text-blue-500/10 absolute inset-0" preserveAspectRatio="none" viewBox="0 0 800 200">
                  <path d="M0,200 L0,150 C50,140 100,170 150,120 S250,40 300,80 S400,100 450,50 S550,20 600,60 S700,90 800,40 L800,200 Z" fill="currentColor"></path>
                </svg>
                <svg className="w-full h-full text-blue-500 relative z-10" preserveAspectRatio="none" viewBox="0 0 800 200">
                  <path d="M0,150 C50,140 100,170 150,120 S250,40 300,80 S400,100 450,50 S550,20 600,60 S700,90 800,40" fill="none" stroke="currentColor" strokeWidth="5" strokeLinecap="round"></path>
                  <circle cx="150" cy="120" r="6" fill={isDarkMode ? '#09090b' : 'white'} stroke="currentColor" strokeWidth="4"></circle>
                  <circle cx="450" cy="50" r="6" fill={isDarkMode ? '#09090b' : 'white'} stroke="currentColor" strokeWidth="4"></circle>
                  <circle cx="800" cy="40" r="6" fill={isDarkMode ? '#09090b' : 'white'} stroke="currentColor" strokeWidth="4"></circle>
                </svg>
              </div>
              <div className="flex justify-between mt-3 text-xs font-semibold text-zinc-400 px-2">
                <span>W1</span><span>W2</span><span>W3</span><span>W4</span><span>W5</span><span>W6</span><span>W7</span>
              </div>
            </div>
          )}
        </div>

        {/* Semi-circle Arc Gauge Card - 5 Cols */}
        <div
          onMouseEnter={triggerGaugeAnimation}
          className={`lg:col-span-5 p-8 rounded-[2.5rem] border-2 float-shadow float-hover smooth-card flex flex-col justify-between transition-colors ${
            isDarkMode ? 'bg-[#18181b] border-[#27272a] text-white' : 'bg-white border-slate-200/80 text-slate-900'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xl font-semibold">Approval Rate</h3>
            <span className="text-[10px] font-semibold text-emerald-500 bg-emerald-500/10 px-3 py-1 rounded-full uppercase tracking-widest">
              Q4
            </span>
          </div>

          <div className="relative w-64 h-40 mx-auto flex flex-col items-center justify-end my-4 cursor-pointer group">
            <svg className="w-64 h-40" viewBox="0 0 200 110">
              <path
                d="M 20 100 A 80 80 0 0 1 180 100"
                fill="none"
                stroke="url(#hatchedPattern)"
                strokeWidth="28"
                strokeLinecap="round"
              />

              <path
                d="M 20 100 A 80 80 0 0 1 180 100"
                fill="none"
                stroke="#38bdf8"
                strokeWidth="28"
                strokeDasharray="251.32"
                strokeDashoffset={inProgressDashOffset}
                strokeLinecap="round"
                className="transition-all duration-700 ease-out"
              />

              <path
                d="M 20 100 A 80 80 0 0 1 180 100"
                fill="none"
                stroke="#004ac6"
                strokeWidth="28"
                strokeDasharray="251.32"
                strokeDashoffset={completedDashOffset}
                strokeLinecap="round"
                className="transition-all duration-700 ease-out"
              />
            </svg>

            <div className="absolute bottom-2 flex flex-col items-center justify-center group-hover:scale-110 transition-transform">
              <span className={`text-4xl font-semibold tracking-tight leading-none ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
                {gaugePercent.toFixed(1)}%
              </span>
              <span className="text-xs font-semibold text-zinc-400 mt-1">Approved</span>
            </div>
          </div>

          <div className={`text-xs font-semibold text-center mb-3 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
            170 approved · 16 rejected this quarter
          </div>

          <div className={`flex justify-between items-center text-xs font-semibold border-t pt-4 mt-2 ${
            isDarkMode ? 'border-zinc-800 text-zinc-300' : 'border-slate-100 text-slate-600'
          }`}>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-[#004ac6]"></span>
              <span>Completed</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-[#38bdf8]"></span>
              <span>Remaining</span>
            </div>
          </div>
        </div>
      </div>

      {/* Documents Requiring Review - Card Grid (Task 7 & Task 2) */}
      <div
        className={`p-8 rounded-[2.5rem] border-2 float-shadow smooth-card ${
          isDarkMode ? 'bg-[#18181b] border-[#27272a] text-white' : 'bg-white border-slate-200/80 text-slate-900'
        }`}
      >
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-xl font-semibold">Documents Requiring Review</h3>
            <p className={`text-xs font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
              Ordered by priority and submission time
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {documentsToReview.map((d) => (
            <div
              key={d.name}
              onClick={() => openDocModal(d)}
              className={`p-6 rounded-[2.5rem] border-2 float-shadow float-hover smooth-card animate-card-pop flex flex-col justify-between transition-all cursor-pointer ${
                isDarkMode ? 'bg-[#121215] border-[#27272a] text-white' : 'bg-slate-50 border-slate-200/80 text-slate-900'
              }`}
            >
              <div className="flex items-start gap-4 mb-4">
                <div
                  className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 text-blue-500 ${
                    isDarkMode ? 'bg-blue-500/10' : 'bg-blue-50'
                  }`}
                >
                  <span className="material-symbols-outlined text-[24px]">{d.icon}</span>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="font-semibold text-sm truncate mb-1">{d.name}</div>
                  <div className={`text-xs font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    {d.agency} · Student: {d.student}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-slate-200/50 dark:border-zinc-800">
                <span
                  className={`text-[10px] font-semibold px-3 py-1 rounded-full border uppercase tracking-widest ${priorityStyles[d.priority]}`}
                >
                  {d.priority} Priority
                </span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    openDocModal(d);
                  }}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-semibold shadow-md shadow-blue-600/30 badge-shadow transition-all hover:scale-105 active:scale-95 cursor-pointer"
                >
                  Review
                  <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
