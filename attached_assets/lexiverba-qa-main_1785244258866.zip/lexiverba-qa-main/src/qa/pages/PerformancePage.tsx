import React from 'react';
import { StatCardGrid } from '../StatCard';

interface Props {
  isDarkMode: boolean;
}

export const PerformancePage: React.FC<Props> = ({ isDarkMode }) => {
  const stats = [
    { id: 0, title: 'TOTAL REVIEWED', value: '186', badge: '18 ▲ This Week', icon: 'fact_check' },
    { id: 1, title: 'APPROVAL RATE', value: '91.2%', badge: 'Above Target', icon: 'trending_up' },
    { id: 2, title: "TODAY'S REVIEWS", value: '7', badge: '2 ▲ Increased', icon: 'today' },
    { id: 3, title: 'WEEKLY REVIEWS', value: '34', badge: 'On Pace', icon: 'calendar_month' },
  ];

  const cardBase = `p-8 rounded-[2.5rem] border-2 float-shadow smooth-card ${
    isDarkMode ? 'bg-[#18181b] border-[#27272a] text-white' : 'bg-white border-slate-200/80 text-slate-900'
  }`;

  const Row = ({ label, value, tone }: { label: string; value: string; tone?: 'emerald' | 'rose' | 'blue' }) => (
    <div className={`flex items-center justify-between py-3 border-b last:border-b-0 ${isDarkMode ? 'border-[#27272a]' : 'border-slate-200/80'}`}>
      <span className={`text-xs font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>{label}</span>
      <span
        className={`text-sm font-semibold ${
          tone === 'emerald' ? 'text-emerald-500' : tone === 'rose' ? 'text-rose-500' : tone === 'blue' ? 'text-blue-500' : ''
        }`}
      >
        {value}
      </span>
    </div>
  );

  return (
    <div className="space-y-8 animate-page-enter">
      <div>
        <h1 className={`text-4xl lg:text-5xl font-semibold tracking-tight leading-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
          Performance
        </h1>
        <p className={`text-sm font-medium mt-1 ${isDarkMode ? 'text-zinc-400' : 'text-slate-500'}`}>
          Your review throughput, approval rate, and efficiency benchmarks.
        </p>
      </div>

      <StatCardGrid cards={stats} isDarkMode={isDarkMode} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className={cardBase}>
          <h3 className="text-xl font-semibold mb-1">Review Breakdown</h3>
          <p className={`text-xs font-semibold mb-4 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
            Split across final outcomes
          </p>
          <Row label="Approved" value="170" tone="emerald" />
          <Row label="Rejected" value="16" tone="rose" />
          <Row label="Escalated" value="4" tone="blue" />
        </div>

        <div className={cardBase}>
          <h3 className="text-xl font-semibold mb-1">Efficiency</h3>
          <p className={`text-xs font-semibold mb-4 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
            Speed of certification decisions
          </p>
          <Row label="Avg Review Time" value="18m 42s" />
          <Row label="Reviews / Day Avg" value="6.8" />
          <Row label="First-Pass Accept" value="82%" tone="emerald" />
        </div>

        <div className={cardBase}>
          <h3 className="text-xl font-semibold mb-1">Performance Level</h3>
          <p className={`text-xs font-semibold mb-4 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
            Current tier
          </p>
          <div className="flex flex-col items-center py-4">
            <div className="w-20 h-20 rounded-full bg-emerald-500/15 text-emerald-500 flex items-center justify-center mb-3 badge-glow-emerald">
              <span className="material-symbols-outlined text-[36px]">workspace_premium</span>
            </div>
            <div className="text-2xl font-semibold text-emerald-500">Excellent</div>
            <div className={`text-xs font-semibold mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
              Top 10% of QA reviewers
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
