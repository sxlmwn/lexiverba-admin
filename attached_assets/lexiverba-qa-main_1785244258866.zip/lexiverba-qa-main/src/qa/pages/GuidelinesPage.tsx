import React, { useState, ReactNode } from 'react';

interface Props {
  isDarkMode: boolean;
  onItemClick?: (title: string, content: ReactNode) => void;
}

const guidelines = [
  { title: 'ISO-17100 Certified Translation Standard', desc: 'Baseline requirements for certified translation output, reviewer competency, and record-keeping.', category: 'Standards', updated: 'Oct 12, 2026', icon: 'menu_book' },
  { title: 'Sworn Stamp Placement Protocol', desc: 'Where sworn seals must appear on multi-page bilingual documents and appendices.', category: 'Legal', updated: 'Oct 08, 2026', icon: 'approval' },
  { title: 'Terminology & Glossary Enforcement', desc: 'How to reconcile client glossaries with domain-specific term bases during QA.', category: 'Linguistic', updated: 'Sep 30, 2026', icon: 'auto_stories' },
  { title: 'Medical Report Review Checklist', desc: 'Dosage units, patient identifiers, and diagnostic code validation before approval.', category: 'Medical', updated: 'Sep 24, 2026', icon: 'medical_services' },
  { title: 'Legal Contract Consistency Rules', desc: 'Clause numbering, defined terms, and jurisdiction naming conventions.', category: 'Legal', updated: 'Sep 18, 2026', icon: 'gavel' },
  { title: 'Rejection Reason Style Guide', desc: 'How to phrase rejection notes so translators can act on them without back-and-forth.', category: 'Process', updated: 'Sep 10, 2026', icon: 'edit_note' },
];

export const GuidelinesPage: React.FC<Props> = ({ isDarkMode, onItemClick }) => {
  const [q, setQ] = useState('');

  const filtered = guidelines.filter(
    (g) => q.trim() === '' || g.title.toLowerCase().includes(q.toLowerCase()) || g.category.toLowerCase().includes(q.toLowerCase()),
  );

  const openGuidelineModal = (g: (typeof guidelines)[0]) => {
    if (!onItemClick) return;
    onItemClick(
      g.title,
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <span className={`text-[10px] font-semibold px-3 py-1 rounded-full uppercase tracking-widest ${isDarkMode ? 'bg-blue-500/10 text-blue-400' : 'bg-blue-50 text-blue-600'}`}>
            {g.category} Protocol
          </span>
          <span className={`text-xs font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
            Updated {g.updated}
          </span>
        </div>

        <div className={`p-4 rounded-2xl border ${isDarkMode ? 'bg-[#18181b] border-[#27272a]' : 'bg-slate-50 border-slate-200'}`}>
          <div className="text-xs font-semibold mb-1">Guideline Summary</div>
          <p className={`text-xs leading-relaxed ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
            {g.desc}
          </p>
        </div>

        <div className={`p-4 rounded-2xl border ${isDarkMode ? 'bg-[#18181b] border-[#27272a]' : 'bg-slate-50 border-slate-200'}`}>
          <div className="text-xs font-semibold mb-1">Compliance Requirement</div>
          <p className={`text-xs leading-relaxed ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
            All certified QA auditors must strictly enforce this rule during final verification passes.
          </p>
        </div>

        <div className="flex justify-end gap-3 pt-2">
          <button
            onClick={() => onItemClick('', null)}
            className="px-5 py-2 rounded-full bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold cursor-pointer shadow-md shadow-blue-600/30"
          >
            Got It
          </button>
        </div>
      </div>,
    );
  };

  return (
    <div className="space-y-8 animate-page-enter">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <h1 className={`text-4xl lg:text-5xl font-semibold tracking-tight leading-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
            Guidelines
          </h1>
          <p className={`text-sm font-medium mt-1 ${isDarkMode ? 'text-zinc-400' : 'text-slate-500'}`}>
            Review protocols, glossaries, and jurisdiction rules.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div
            className={`flex items-center rounded-full px-4 py-2.5 w-[260px] border ${
              isDarkMode ? 'bg-[#18181b] border-[#27272a]' : 'bg-white border-slate-200/80'
            }`}
          >
            <span className="material-symbols-outlined text-slate-400 text-[18px]">search</span>
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search guidelines..."
              className={`bg-transparent border-none text-xs w-full ml-2 outline-none font-semibold placeholder-slate-400 ${
                isDarkMode ? 'text-white' : 'text-slate-800'
              }`}
            />
          </div>
          <button className="flex items-center gap-2 px-5 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-full shadow-lg shadow-blue-600/30 transition-all hover:scale-105 active:scale-95 float-hover cursor-pointer">
            <span className="material-symbols-outlined text-[18px]">add</span>
            Add New Guideline
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filtered.map((g) => (
          <div
            key={g.title}
            onClick={() => openGuidelineModal(g)}
            className={`p-6 rounded-[2.5rem] border-2 smooth-card float-shadow float-hover transition-all cursor-pointer ${
              isDarkMode ? 'bg-[#18181b] border-[#27272a] text-white' : 'bg-white border-slate-200/80 text-slate-900'
            }`}
          >
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-lg shadow-blue-600/30 shrink-0">
                <span className="material-symbols-outlined text-[24px]">{g.icon}</span>
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-start justify-between gap-2">
                  <h3 className="font-semibold text-sm">{g.title}</h3>
                  <span
                    className={`text-[10px] font-semibold px-2.5 py-0.5 rounded-full uppercase tracking-widest shrink-0 ${
                      isDarkMode ? 'bg-blue-500/10 text-blue-400' : 'bg-blue-50 text-blue-600'
                    }`}
                  >
                    {g.category}
                  </span>
                </div>
                <p className={`text-xs font-medium mt-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>{g.desc}</p>
                <div className={`text-[11px] font-semibold mt-3 ${isDarkMode ? 'text-slate-500' : 'text-slate-400'}`}>
                  Last updated {g.updated}
                </div>
                <div className="flex items-center gap-2 mt-4">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      openGuidelineModal(g);
                    }}
                    className={`flex items-center gap-1.5 px-4 py-2 rounded-full border text-[11px] font-semibold transition-all hover:scale-105 active:scale-95 cursor-pointer ${
                      isDarkMode ? 'bg-[#121215] border-[#27272a] text-slate-200 hover:bg-zinc-800' : 'bg-white border-slate-200/80 text-slate-800 hover:bg-slate-50'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[14px]">visibility</span>
                    View
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      openGuidelineModal(g);
                    }}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-semibold shadow-md shadow-blue-600/30 badge-shadow transition-all hover:scale-105 active:scale-95 cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[14px]">download</span>
                    Download
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
