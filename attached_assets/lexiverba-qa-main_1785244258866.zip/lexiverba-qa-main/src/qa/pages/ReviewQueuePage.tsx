import React, { useState, ReactNode } from 'react';

interface Props {
  isDarkMode: boolean;
  onItemClick?: (title: string, content: ReactNode) => void;
}

type Status = 'Pending' | 'Approved' | 'Rejected';

interface Doc {
  id: string;
  name: string;
  agency: string;
  student: string;
  submitted: string;
  status: Status;
  icon: string;
}

const allDocs: Doc[] = [
  { id: 'D-1042', name: 'Legal Contract DE/EN Final.pdf', agency: 'Acme Global Corp', student: 'M. Klein', submitted: '2h ago', status: 'Pending', icon: 'gavel' },
  { id: 'D-1041', name: 'Medical Report ES/EN v2.docx', agency: 'Helios Pharma', student: 'A. Ruiz', submitted: '5h ago', status: 'Pending', icon: 'medical_services' },
  { id: 'D-1040', name: 'Birth Certificate FR/EN.pdf', agency: 'Vanguard Legal', student: 'C. Dubois', submitted: '6h ago', status: 'Pending', icon: 'badge' },
  { id: 'D-1039', name: 'University Transcript IT/EN.pdf', agency: 'Global Edu Services', student: 'G. Rossi', submitted: '8h ago', status: 'Pending', icon: 'school' },
  { id: 'D-1038', name: 'Commercial Lease DE/EN.pdf', agency: 'Apex Properties', student: 'K. Schmidt', submitted: '10h ago', status: 'Pending', icon: 'gavel' },
  { id: 'D-1037', name: 'Tax Return Document JP/EN.pdf', agency: 'Nippon Finance', student: 'T. Tanaka', submitted: '12h ago', status: 'Pending', icon: 'table_chart' },
  { id: 'D-1036', name: 'Clinical Trial ES/EN.pdf', agency: 'BioHealth Labs', student: 'E. Morales', submitted: '14h ago', status: 'Pending', icon: 'medical_services' },
  { id: 'D-1035', name: 'Corporate Bylaws PT/EN.docx', agency: 'Luso Tech', student: 'F. Silva', submitted: '18h ago', status: 'Pending', icon: 'description' },
  { id: 'D-1034', name: 'Patent Application ZH/EN.pdf', agency: 'Quantum Dynamics', student: 'L. Wei', submitted: '1d ago', status: 'Approved', icon: 'description' },
  { id: 'D-1033', name: 'Diploma FR/EN Certified.pdf', agency: 'Vanguard Legal', student: 'C. Dubois', submitted: '2d ago', status: 'Rejected', icon: 'school' },
  { id: 'D-1032', name: 'Financial Statement 2026.xlsx', agency: 'Meridian Audit', student: 'R. Park', submitted: '3d ago', status: 'Approved', icon: 'table_chart' },
];

const statusStyles: Record<Status, string> = {
  Pending: 'bg-amber-500/10 text-amber-500 border-amber-500/30 badge-glow-amber',
  Approved: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/30 badge-glow-emerald',
  Rejected: 'bg-rose-500/10 text-rose-500 border-rose-500/30 badge-glow-rose',
};

export const ReviewQueuePage: React.FC<Props> = ({ isDarkMode, onItemClick }) => {
  const [tab, setTab] = useState<'All' | Status>('All');
  const [q, setQ] = useState('');
  const [viewType, setViewType] = useState<'grid' | 'table'>('grid');

  const counts = {
    All: allDocs.length,
    Pending: allDocs.filter((d) => d.status === 'Pending').length,
    Approved: allDocs.filter((d) => d.status === 'Approved').length,
    Rejected: allDocs.filter((d) => d.status === 'Rejected').length,
  };

  const filtered = allDocs.filter(
    (d) =>
      (tab === 'All' || d.status === tab) &&
      (q.trim() === '' || d.name.toLowerCase().includes(q.toLowerCase()) || d.agency.toLowerCase().includes(q.toLowerCase())),
  );

  const tabs: (keyof typeof counts)[] = ['All', 'Pending', 'Approved', 'Rejected'];

  const openQueueModal = (d: Doc) => {
    if (!onItemClick) return;
    onItemClick(
      d.name,
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <span className={`text-[10px] font-semibold px-3 py-1 rounded-full border uppercase tracking-widest ${statusStyles[d.status]}`}>
            {d.status}
          </span>
          <span className={`text-xs font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
            {d.id} · Submitted {d.submitted}
          </span>
        </div>

        <div className={`p-4 rounded-2xl border ${isDarkMode ? 'bg-[#18181b] border-[#27272a]' : 'bg-slate-50 border-slate-200'}`}>
          <div className="text-xs font-semibold mb-1">Agency & Student Meta</div>
          <div className={`text-sm ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>{d.agency}</div>
          <div className={`text-xs mt-0.5 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Student: {d.student}</div>
        </div>

        <div className="flex justify-end gap-3 pt-2">
          <button
            onClick={() => onItemClick('', null)}
            className="px-5 py-2 rounded-full bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold cursor-pointer shadow-md shadow-blue-600/30"
          >
            Close Details
          </button>
        </div>
      </div>,
    );
  };

  return (
    <div className="space-y-8 animate-page-enter">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <h1 className={`text-4xl lg:text-5xl font-semibold tracking-tight leading-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
            Review Queue
          </h1>
          <p className={`text-sm font-medium mt-1 ${isDarkMode ? 'text-zinc-400' : 'text-slate-500'}`}>
            Every document awaiting your certification decision.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Grid / Table View Switcher */}
          <div className={`flex p-1 rounded-full border ${isDarkMode ? 'bg-[#18181b] border-[#27272a]' : 'bg-white border-slate-200/80'}`}>
            <button
              onClick={() => setViewType('grid')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-full transition-all flex items-center gap-1.5 cursor-pointer ${
                viewType === 'grid' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span className="material-symbols-outlined text-[16px]">grid_view</span>
              <span>Grid</span>
            </button>
            <button
              onClick={() => setViewType('table')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-full transition-all flex items-center gap-1.5 cursor-pointer ${
                viewType === 'table' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span className="material-symbols-outlined text-[16px]">table_rows</span>
              <span>Table</span>
            </button>
          </div>

          <div
            className={`flex items-center rounded-full px-4 py-2.5 w-[240px] border ${
              isDarkMode ? 'bg-[#18181b] border-[#27272a]' : 'bg-white border-slate-200/80'
            }`}
          >
            <span className="material-symbols-outlined text-slate-400 text-[18px]">search</span>
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search documents..."
              className={`bg-transparent border-none text-xs w-full ml-2 outline-none font-semibold placeholder-slate-400 ${
                isDarkMode ? 'text-white' : 'text-slate-800'
              }`}
            />
          </div>

          <button
            className={`flex items-center gap-2 px-5 py-3 rounded-full border font-semibold text-xs transition-all hover:scale-105 active:scale-95 cursor-pointer ${
              isDarkMode ? 'bg-[#18181b] border-[#27272a] text-white' : 'bg-white border-slate-200/80 text-slate-800'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">refresh</span>
            Refresh
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className={`inline-flex p-1.5 rounded-full border-2 ${isDarkMode ? 'bg-[#18181b] border-[#27272a]' : 'bg-white border-slate-200/80'}`}>
        {tabs.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t as any)}
            className={`flex items-center gap-2 px-5 py-2 rounded-full text-xs font-semibold transition-all cursor-pointer ${
              tab === t
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : isDarkMode
                ? 'text-slate-400 hover:text-white'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            {t}
            <span
              className={`text-[10px] font-semibold px-2 py-0.5 rounded-md ${
                tab === t ? 'bg-white/20 text-white' : isDarkMode ? 'bg-zinc-800 text-zinc-300' : 'bg-slate-100 text-slate-600'
              }`}
            >
              {counts[t]}
            </span>
          </button>
        ))}
      </div>

      {/* Content: Grid or Table */}
      {filtered.length === 0 ? (
        <div className={`p-16 rounded-[2.5rem] border-2 float-shadow smooth-card flex flex-col items-center justify-center text-center ${
          isDarkMode ? 'bg-[#18181b] border-[#27272a]' : 'bg-white border-slate-200/80'
        }`}>
          <div
            className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-4 ${
              isDarkMode ? 'bg-[#121215] text-slate-500' : 'bg-slate-100 text-slate-400'
            }`}
          >
            <span className="material-symbols-outlined text-[32px]">folder_off</span>
          </div>
          <div className={`text-sm font-semibold ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
            No documents found
          </div>
          <div className={`text-xs font-medium mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
            Try changing filters or refreshing the queue.
          </div>
        </div>
      ) : viewType === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((d) => (
            <div
              key={d.id}
              onClick={() => openQueueModal(d)}
              className={`p-6 rounded-[2.5rem] border-2 float-shadow float-hover smooth-card animate-card-pop flex flex-col justify-between transition-all cursor-pointer ${
                isDarkMode ? 'bg-[#18181b] border-[#27272a] text-white' : 'bg-white border-slate-200/80 text-slate-900'
              }`}
            >
              <div>
                <div className="flex items-start gap-4 mb-4">
                  <div
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 text-blue-500 ${
                      isDarkMode ? 'bg-blue-500/10' : 'bg-blue-50'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[24px]">{d.icon}</span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="font-semibold text-sm truncate mb-1">{d.name}</div>
                    <div className={`text-xs font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                      {d.agency} · Student: {d.student}
                    </div>
                    <div className={`text-[10px] font-semibold mt-1 ${isDarkMode ? 'text-slate-500' : 'text-slate-400'}`}>
                      {d.id} · {d.submitted}
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-slate-200/50 dark:border-zinc-800 mt-4">
                <span className={`text-[10px] font-semibold px-3 py-1 rounded-full border uppercase tracking-widest ${statusStyles[d.status]}`}>
                  {d.status}
                </span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    openQueueModal(d);
                  }}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-semibold shadow-md shadow-blue-600/30 badge-shadow transition-all hover:scale-105 active:scale-95 cursor-pointer"
                >
                  Open
                  <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div
          className={`rounded-[2.5rem] border-2 float-shadow smooth-card overflow-hidden ${
            isDarkMode ? 'bg-[#18181b] border-[#27272a]' : 'bg-white border-slate-200/80'
          }`}
        >
          <table className="w-full text-left">
            <thead>
              <tr className={`text-[10px] font-semibold uppercase tracking-widest ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                <th className="px-6 py-4">Document</th>
                <th className="px-6 py-4">Agency</th>
                <th className="px-6 py-4">Student</th>
                <th className="px-6 py-4">Submitted</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((d) => (
                <tr
                  key={d.id}
                  onClick={() => openQueueModal(d)}
                  className={`border-t ${isDarkMode ? 'border-[#27272a] hover:bg-[#121215]' : 'border-slate-200/80 hover:bg-slate-50'} transition-colors cursor-pointer`}
                >
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-2xl flex items-center justify-center text-blue-500 ${isDarkMode ? 'bg-blue-500/10' : 'bg-blue-50'}`}>
                        <span className="material-symbols-outlined text-[20px]">{d.icon}</span>
                      </div>
                      <div>
                        <div className={`text-xs font-semibold ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>{d.name}</div>
                        <div className={`text-[10px] font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>{d.id}</div>
                      </div>
                    </div>
                  </td>
                  <td className={`px-6 py-4 text-xs font-semibold ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>{d.agency}</td>
                  <td className={`px-6 py-4 text-xs font-semibold ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>{d.student}</td>
                  <td className={`px-6 py-4 text-xs font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>{d.submitted}</td>
                  <td className="px-6 py-4">
                    <span className={`text-[10px] font-semibold px-3 py-1 rounded-full border uppercase tracking-widest ${statusStyles[d.status]}`}>
                      {d.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        openQueueModal(d);
                      }}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-semibold shadow-md shadow-blue-600/30 badge-shadow transition-all hover:scale-105 active:scale-95 cursor-pointer"
                    >
                      Open
                      <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
