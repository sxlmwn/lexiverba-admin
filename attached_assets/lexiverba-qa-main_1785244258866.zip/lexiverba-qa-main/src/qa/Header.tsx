import React, { useState } from 'react';

interface HeaderProps {
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  isCollapsed?: boolean;
  title: string;
  subtitle: string;
}

export const Header: React.FC<HeaderProps> = ({
  isDarkMode,
  toggleDarkMode,
  isCollapsed = false,
  title,
  subtitle,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const unreadCount = 3;

  return (
    <header
      className={`fixed top-0 right-0 h-20 backdrop-blur-xl border-b-2 z-40 px-10 flex items-center justify-between transition-all duration-300 ease-in-out ${
        isCollapsed ? 'left-20' : 'left-72'
      } ${
        isDarkMode ? 'bg-[#121215]/90 border-[#27272a] text-slate-100' : 'bg-white/80 border-slate-200/50 text-slate-900'
      }`}
    >
      <div>
        <h2 className={`text-lg font-semibold tracking-tight ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
          {title}
        </h2>
        <p className={`text-xs font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
          {subtitle}
        </p>
      </div>

      <div className="flex items-center gap-4">
        <div
          className={`flex items-center rounded-2xl px-4 py-2.5 w-[340px] border transition-all ${
            isSearchFocused
              ? isDarkMode
                ? 'bg-[#18181b] border-blue-500 shadow-lg shadow-blue-500/10'
                : 'bg-white border-blue-600 shadow-lg shadow-blue-600/10'
              : isDarkMode
              ? 'bg-[#18181b] border-[#27272a]'
              : 'bg-slate-100/80 border-slate-200/60'
          }`}
        >
          <span className="material-symbols-outlined text-slate-400 text-[20px]">search</span>
          <input
            type="text"
            value={searchQuery}
            onFocus={() => setIsSearchFocused(true)}
            onBlur={() => setIsSearchFocused(false)}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search documents, reviewers..."
            className={`bg-transparent border-none text-xs w-full ml-2 outline-none font-semibold placeholder-slate-400 ${
              isDarkMode ? 'text-white' : 'text-slate-800'
            }`}
          />
          <kbd
            className={`px-2 py-0.5 border text-[10px] font-semibold rounded-md shadow-2xs ${
              isDarkMode ? 'bg-zinc-800 border-zinc-700 text-zinc-300' : 'bg-white border-slate-200 text-slate-400'
            }`}
          >
            ⌘F
          </kbd>
        </div>

        <button
          className={`flex items-center gap-2 px-4 py-2.5 rounded-full border font-semibold text-xs transition-all hover:scale-105 active:scale-95 cursor-pointer ${
            isDarkMode
              ? 'bg-[#18181b] border-[#27272a] text-slate-200 hover:bg-zinc-800'
              : 'bg-white border-slate-200/80 text-slate-700 hover:bg-slate-50'
          }`}
        >
          <span className="material-symbols-outlined text-[18px]">support_agent</span>
          Support
        </button>

        <button
          onClick={toggleDarkMode}
          className={`w-10 h-10 rounded-full border flex items-center justify-center transition-all shadow-2xs hover:scale-105 active:scale-95 cursor-pointer ${
            isDarkMode
              ? 'bg-[#18181b] border-[#27272a] text-amber-400 hover:bg-zinc-800'
              : 'bg-white border-slate-200/80 text-slate-700 hover:bg-slate-50'
          }`}
          title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
        >
          <span className="material-symbols-outlined text-[20px]">
            {isDarkMode ? 'light_mode' : 'dark_mode'}
          </span>
        </button>

        <button
          className={`w-10 h-10 rounded-full border flex items-center justify-center transition-all shadow-2xs relative cursor-pointer hover:scale-105 active:scale-95 ${
            isDarkMode
              ? 'bg-[#18181b] border-[#27272a] text-slate-300 hover:bg-zinc-800'
              : 'bg-white border-slate-200/80 text-slate-600 hover:bg-slate-50'
          }`}
          title="Notifications"
        >
          <span className="material-symbols-outlined text-[20px]">notifications</span>
          {unreadCount > 0 && (
            <span
              className={`absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 bg-rose-500 text-white text-[10px] font-semibold rounded-full ring-2 flex items-center justify-center ${
                isDarkMode ? 'ring-[#121215]' : 'ring-white'
              }`}
            >
              {unreadCount}
            </span>
          )}
        </button>

        <button
          className={`flex items-center gap-2 pl-1 pr-3 py-1 rounded-full border transition-all hover:scale-[1.02] cursor-pointer ${
            isDarkMode ? 'bg-[#18181b] border-[#27272a]' : 'bg-white border-slate-200/80'
          }`}
        >
          <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-semibold text-xs">
            SR
          </div>
          <div className="text-left">
            <div className={`text-xs font-semibold ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
              Sofia Reyes
            </div>
            <div className="text-[10px] font-semibold text-slate-400">QA Reviewer</div>
          </div>
          <span className="material-symbols-outlined text-slate-400 text-[18px]">expand_more</span>
        </button>
      </div>
    </header>
  );
};
